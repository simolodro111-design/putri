/* ============================================================
   DATA & PERSONALIZATION
   Edit semua isi kamu di sini. Tidak perlu sentuh file lain.
   ============================================================ */

const CONFIG = {

  // tanggal jadian (dipakai untuk counter otomatis)
  // format: "YYYY-MM-DDTHH:MM:SS"
  relationshipStart: "2026-07-12T00:00:00",

  // musik latar (opsional). taruh file mp3 kamu di folder /music
  // dan ganti nama file di bawah ini kalau perlu.
  musicFile: "music/song.mp3",

  // ==========================================================
  // TIMELINE — "our little story"
  // tambah / hapus / edit item sesuka kamu di sini
  // ==========================================================
  timeline: [
    {
      date: "12 juli 2026",
      title: "the day our story started",
      text: "hari dimana dua orang memutuskan untuk memulai satu cerita bersama."
    },
    {
      date: "",
      title: "our first memories",
      text: "hal-hal kecil yang akhirnya jadi sesuatu yang berarti."
    },
    {
      date: "",
      title: "random days with you",
      text: "ngga selalu harus ada alasan buat bahagia, kadang cukup karena ada kamu."
    },
    {
      date: "",
      title: "more memories to come",
      text: "ini baru awal, masih banyak cerita yang belum kita tulis."
    }
  ],

  // ==========================================================
  // FOTO — "little moments with you"
  // ganti "src" dengan path foto kamu sendiri di folder /images
  // (contoh: images/foto1.jpg). caption bebas kamu ubah.
  // "size" mengatur bentuk kartu: "polaroid" | "landscape" | "portrait"
  // ==========================================================
  photos: [
    { src: "images/foto1.jpg", caption: "one of my favorite days", size: "polaroid" },
    { src: "images/foto2.jpg", caption: "just us being us", size: "landscape" },
    { src: "images/foto3.jpg", caption: "another memory i want to keep", size: "portrait" },
    { src: "images/foto4.jpg", caption: "ternyata sesederhana ini ya bahagianya", size: "polaroid" },
    { src: "images/foto5.jpg", caption: "random moment, favorite moment", size: "landscape" },
    { src: "images/foto6.jpg", caption: "yang ini juga aku suka banget", size: "polaroid" },
    { src: "images/foto7.jpg", caption: "still my favorite person", size: "portrait" },
    { src: "images/foto8.jpg", caption: "to many more of these", size: "polaroid" }
  ],

  // ==========================================================
  // 20 THINGS I LOVE ABOUT YOU
  // ==========================================================
  things: [
    "cara kamu tersenyum",
    "cara kamu cerita",
    "cara kamu bikin suasana jadi lebih nyaman",
    "perhatian kecil kamu",
    "cara kamu jadi diri sendiri",
    "suara kamu",
    "cara kamu ketawa",
    "momen-momen random kita",
    "cara kamu peduli",
    "kamu yang selalu punya sisi unik",
    "cara kamu melihat sesuatu",
    "obrolan kecil kita",
    "waktu yang kita habiskan bareng",
    "kejutan-kejutan kecil kamu",
    "cara kamu membuat hari biasa terasa berbeda",
    "semua kenangan yang sudah kita buat",
    "sisi manja kamu",
    "sisi kuat kamu",
    "semua hal kecil yang mungkin kamu sendiri ngga sadar",
    "karena kamu adalah kamu"
  ]
};
