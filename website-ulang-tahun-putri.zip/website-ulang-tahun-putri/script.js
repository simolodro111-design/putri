/* ============================================================
   SCRIPT — semua interaksi & animasi
   (data yang bisa kamu edit ada di data.js)
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {

  /* ---------- OPENING → MAIN CONTENT ---------- */
  const opening = document.getElementById('opening');
  const mainContent = document.getElementById('mainContent');
  const openGiftBtn = document.getElementById('openGiftBtn');

  openGiftBtn.addEventListener('click', () => {
    opening.classList.add('leaving');
    mainContent.hidden = false;
    spawnConfetti();
    startHeroTyping();
    setTimeout(() => { opening.style.display = 'none'; }, 850);
    document.body.style.overflow = 'auto';
  });

  document.getElementById('replayBtn').addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  /* ---------- FLOATING PARTICLES ---------- */
  const particleLayer = document.getElementById('particles');
  const particleEmojis = ['🤍', '✨', '💛'];
  function spawnParticle(){
    const el = document.createElement('span');
    el.className = 'particle';
    el.textContent = particleEmojis[Math.floor(Math.random() * particleEmojis.length)];
    el.style.left = Math.random() * 100 + 'vw';
    el.style.setProperty('--drift', (Math.random() * 60 - 30) + 'px');
    const duration = 9 + Math.random() * 6;
    el.style.animationDuration = duration + 's';
    particleLayer.appendChild(el);
    setTimeout(() => el.remove(), duration * 1000);
  }
  setInterval(spawnParticle, 1400);

  /* ---------- PROGRESS BAR + BACK TO TOP ---------- */
  const progressFill = document.getElementById('progressFill');
  const toTopBtn = document.getElementById('toTop');
  window.addEventListener('scroll', () => {
    const h = document.documentElement;
    const scrolled = (h.scrollTop) / (h.scrollHeight - h.clientHeight) * 100;
    progressFill.style.width = (scrolled || 0) + '%';
    toTopBtn.classList.toggle('visible', h.scrollTop > 400);
  });
  toTopBtn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

  /* ---------- MUSIC TOGGLE ---------- */
  const musicToggle = document.getElementById('musicToggle');
  const bgMusic = document.getElementById('bgMusic');
  let musicOn = false;
  musicToggle.addEventListener('click', () => {
    musicOn = !musicOn;
    if (musicOn) {
      bgMusic.volume = 0.5;
      bgMusic.play().catch(() => { /* file musik belum ada, aman diabaikan */ });
      musicToggle.classList.add('playing');
      musicToggle.setAttribute('aria-label', 'matikan musik');
    } else {
      bgMusic.pause();
      musicToggle.classList.remove('playing');
      musicToggle.setAttribute('aria-label', 'nyalakan musik');
    }
  });

  /* ---------- HERO TYPING ANIMATION (once, via IntersectionObserver) ---------- */
  const heroTyping = document.getElementById('heroTyping');
  let typingStarted = false;
  function startHeroTyping(){
    if (typingStarted) return;
    typingStarted = true;
    const fullText = heroTyping.getAttribute('data-text');
    heroTyping.textContent = '';
    let i = 0;
    const step = () => {
      if (i <= fullText.length) {
        heroTyping.textContent = fullText.slice(0, i);
        i++;
        setTimeout(step, 16);
      }
    };
    setTimeout(step, 500);
  }

  /* ---------- CONFETTI (hero section, once) ---------- */
  const confettiLayer = document.getElementById('confettiLayer');
  const confettiColors = ['#F6C445', '#B7D9A6', '#F3B6B6', '#FFFDF7'];
  function spawnConfetti(){
    for (let i = 0; i < 26; i++) {
      const piece = document.createElement('span');
      piece.className = 'confetti-piece';
      piece.style.left = Math.random() * 100 + '%';
      piece.style.background = confettiColors[Math.floor(Math.random() * confettiColors.length)];
      piece.style.animationDuration = (2.4 + Math.random() * 1.6) + 's';
      piece.style.animationDelay = (Math.random() * 0.6) + 's';
      confettiLayer.appendChild(piece);
      setTimeout(() => piece.remove(), 5000);
    }
  }

  /* ---------- LOVE LETTER SEAL ---------- */
  const letterSeal = document.getElementById('letterSeal');
  letterSeal.addEventListener('click', () => {
    letterSeal.classList.add('opened');
  });

  /* ---------- TIMELINE (from CONFIG) ---------- */
  const timelineEl = document.getElementById('timeline');
  CONFIG.timeline.forEach(item => {
    const div = document.createElement('div');
    div.className = 'timeline-item';
    div.innerHTML = `
      <span class="timeline-dot"></span>
      ${item.date ? `<div class="timeline-date">${item.date}</div>` : ''}
      <div class="timeline-title">${item.title}</div>
      <div class="timeline-text">${item.text}</div>
    `;
    timelineEl.appendChild(div);
  });

  /* ---------- GALLERY (from CONFIG) ---------- */
  const galleryGrid = document.getElementById('galleryGrid');
  const lightbox = document.getElementById('lightbox');
  const lightboxImg = document.getElementById('lightboxImg');
  const lightboxCaption = document.getElementById('lightboxCaption');
  const lightboxClose = document.getElementById('lightboxClose');

  CONFIG.photos.forEach(photo => {
    const card = document.createElement('div');
    card.className = 'photo-card ' + (photo.size || 'polaroid');
    const img = document.createElement('img');
    img.src = photo.src;
    img.alt = photo.caption || 'kenangan kita';
    img.loading = 'lazy';
    img.onerror = () => {
      const fallback = document.createElement('div');
      fallback.className = 'photo-fallback';
      fallback.textContent = '📷';
      img.replaceWith(fallback);
    };
    const cap = document.createElement('p');
    cap.className = 'cap';
    cap.textContent = photo.caption || '';
    card.appendChild(img);
    card.appendChild(cap);
    card.addEventListener('click', () => {
      lightboxImg.src = photo.src;
      lightboxCaption.textContent = photo.caption || '';
      lightbox.classList.add('open');
    });
    galleryGrid.appendChild(card);
  });
  lightboxClose.addEventListener('click', () => lightbox.classList.remove('open'));
  lightbox.addEventListener('click', (e) => { if (e.target === lightbox) lightbox.classList.remove('open'); });

  /* ---------- SECRET DINO EASTER EGG ---------- */
  const secretDino = document.getElementById('secretDino');
  secretDino.addEventListener('click', () => {
    secretDino.classList.add('tapped');
    setTimeout(() => secretDino.classList.remove('tapped'), 500);
  });

  /* ---------- 20 THINGS (from CONFIG) ---------- */
  const thingsGrid = document.getElementById('thingsGrid');
  CONFIG.things.forEach((text, idx) => {
    const card = document.createElement('div');
    card.className = 'thing-card';
    const num = document.createElement('span');
    num.className = 'thing-num';
    num.textContent = String(idx + 1).padStart(2, '0');
    const full = document.createElement('span');
    full.className = 'thing-text';
    full.textContent = text;
    card.appendChild(num);
    card.appendChild(full);
    card.addEventListener('click', () => card.classList.toggle('opened'));
    thingsGrid.appendChild(card);
  });

  /* ---------- RELATIONSHIP COUNTER ---------- */
  const startDate = new Date(CONFIG.relationshipStart);
  const cDays = document.getElementById('cDays');
  const cHours = document.getElementById('cHours');
  const cMinutes = document.getElementById('cMinutes');
  const cSeconds = document.getElementById('cSeconds');
  function updateCounter(){
    const now = new Date();
    let diff = Math.max(0, now - startDate);
    const days = Math.floor(diff / 86400000);
    const hours = Math.floor((diff % 86400000) / 3600000);
    const minutes = Math.floor((diff % 3600000) / 60000);
    const seconds = Math.floor((diff % 60000) / 1000);
    cDays.textContent = days;
    cHours.textContent = String(hours).padStart(2, '0');
    cMinutes.textContent = String(minutes).padStart(2, '0');
    cSeconds.textContent = String(seconds).padStart(2, '0');
  }
  updateCounter();
  setInterval(updateCounter, 1000);

  /* ---------- MINI SURPRISE ---------- */
  const surpriseBtn = document.getElementById('surpriseBtn');
  const surpriseReveal = document.getElementById('surpriseReveal');
  surpriseBtn.addEventListener('click', () => {
    surpriseReveal.hidden = false;
    surpriseBtn.hidden = true;
  });

  /* ---------- FINAL SECTION STARS ---------- */
  const starsLayer = document.getElementById('stars');
  for (let i = 0; i < 40; i++) {
    const star = document.createElement('span');
    star.className = 'star';
    star.style.left = Math.random() * 100 + '%';
    star.style.top = Math.random() * 80 + '%';
    star.style.animationDelay = (Math.random() * 2.6) + 's';
    starsLayer.appendChild(star);
  }

  /* ---------- REVEAL ON SCROLL (sections fade up once) ---------- */
  const revealTargets = document.querySelectorAll('.screen');
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });
  revealTargets.forEach(t => {
    t.style.opacity = '0';
    t.style.transform = 'translateY(24px)';
    t.style.transition = 'opacity .8s cubic-bezier(.22,.9,.3,1), transform .8s cubic-bezier(.22,.9,.3,1)';
    io.observe(t);
  });
  // opening & hero already visible by default flow
  opening.style.opacity = '1';
  opening.style.transform = 'none';

});
